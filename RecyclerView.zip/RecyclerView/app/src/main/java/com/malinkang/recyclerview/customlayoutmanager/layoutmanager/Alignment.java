package com.malinkang.recyclerview.customlayoutmanager.layoutmanager;

/**
 * Created by xhan on 4/11/16.
 */
public enum Alignment {
	LEFT,
	RIGHT
}
